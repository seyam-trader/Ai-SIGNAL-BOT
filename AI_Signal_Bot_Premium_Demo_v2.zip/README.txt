AI Signal Bot — Premium Demo v2

New:
- Uploaded logo included as logo.png
- Bot name can be changed from Settings
- Local password can be changed from Settings
- Share Bot button uses the device share sheet when available
- Premium floating overlay UI

Safety scope:
- Demo/paper analysis only
- No Quotex connection
- No live chart reading
- No order placement or real-money automation
