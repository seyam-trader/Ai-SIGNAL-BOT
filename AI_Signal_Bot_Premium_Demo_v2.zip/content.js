(() => {
  if (window.__aiSignalPremiumDemoInjected) return;
  window.__aiSignalPremiumDemoInjected = true;
  const host=document.createElement("iframe");
  host.src=chrome.runtime.getURL("overlay.html");
  host.style.cssText="position:fixed;right:0;top:0;width:350px;height:570px;border:0;z-index:2147483647;background:transparent;";
  host.title="AI Signal Bot Premium Demo";
  document.documentElement.appendChild(host);
})();