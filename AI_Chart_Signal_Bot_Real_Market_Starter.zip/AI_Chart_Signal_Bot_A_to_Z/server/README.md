# Server architecture scaffold

Recommended production flow:

Android app
  -> HTTPS authentication
  -> API gateway
  -> account/license service
  -> device authorization
  -> market-data service
  -> analysis service
  -> signal response

Do not store admin passwords in the Android source.

Suggested API endpoints:
POST /auth/login
POST /admin/users
POST /admin/users/{id}/revoke
POST /admin/devices/authorize
POST /admin/devices/revoke
GET  /markets
POST /analysis/screen
POST /analysis/camera
POST /paper-trades
GET  /performance

Authentication should use short-lived access tokens and secure password hashing on the server. Use HTTPS only.

This folder is an architecture guide, not a production authentication server.
