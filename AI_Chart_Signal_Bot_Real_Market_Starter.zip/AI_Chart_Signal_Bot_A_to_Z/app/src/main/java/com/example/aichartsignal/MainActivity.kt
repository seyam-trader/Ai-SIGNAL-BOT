package com.example.aichartsignal

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.*
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.abs
import kotlin.math.max

class MainActivity : AppCompatActivity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val tv = TextView(this).apply {
            text = "Loading live market data…"
            textSize = 18f
            setPadding(32, 64, 32, 32)
        }
        setContentView(tv)

        scope.launch {
            try {
                val candles = withContext(Dispatchers.IO) {
                    fetchCandles("BTCUSDT", "1m", 200)
                }
                val closes = candles.map { it.close }
                val ema9 = ema(closes, 9)
                val ema21 = ema(closes, 21)
                val rsi14 = rsi(closes, 14)
                val signal = when {
                    ema9 > ema21 && rsi14 < 70 -> "BULLISH"
                    ema9 < ema21 && rsi14 > 30 -> "BEARISH"
                    else -> "NEUTRAL"
                }
                tv.text = """
                    BTC/USDT — live market snapshot

                    Last: ${"%.2f".format(closes.last())}
                    EMA 9: ${"%.2f".format(ema9)}
                    EMA 21: ${"%.2f".format(ema21)}
                    RSI 14: ${"%.1f".format(rsi14)}

                    Analysis: $signal

                    This is an analysis signal, not a guaranteed prediction.
                """.trimIndent()
            } catch (e: Exception) {
                tv.text = "Market data error:\n${e.message}"
            }
        }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private data class Candle(val close: Double)

    private fun fetchCandles(symbol: String, interval: String, limit: Int): List<Candle> {
        val url = URL("https://api.binance.com/api/v3/klines?symbol=$symbol&interval=$interval&limit=$limit")
        val conn = url.openConnection() as HttpURLConnection
        conn.requestMethod = "GET"
        conn.connectTimeout = 10000
        conn.readTimeout = 10000
        if (conn.responseCode !in 200..299) error("HTTP ${conn.responseCode}")
        val body = conn.inputStream.bufferedReader().use { it.readText() }
        val arr = JSONArray(body)
        return (0 until arr.length()).map {
            Candle(arr.getJSONArray(it).getString(4).toDouble())
        }
    }

    private fun ema(values: List<Double>, period: Int): Double {
        require(values.size >= period)
        val k = 2.0 / (period + 1)
        var e = values.take(period).average()
        for (v in values.drop(period)) e = v * k + e * (1 - k)
        return e
    }

    private fun rsi(values: List<Double>, period: Int): Double {
        require(values.size > period)
        var gains = 0.0
        var losses = 0.0
        for (i in 1..period) {
            val d = values[i] - values[i - 1]
            if (d >= 0) gains += d else losses -= d
        }
        var avgGain = gains / period
        var avgLoss = losses / period
        for (i in (period + 1) until values.size) {
            val d = values[i] - values[i - 1]
            val gain = max(d, 0.0)
            val loss = max(-d, 0.0)
            avgGain = (avgGain * (period - 1) + gain) / period
            avgLoss = (avgLoss * (period - 1) + loss) / period
        }
        if (avgLoss == 0.0) return 100.0
        val rs = avgGain / avgLoss
        return 100.0 - (100.0 / (1.0 + rs))
    }
}
